<?php

namespace Database\Seeders;

use Faker\Factory as Faker;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class DealinSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');

        for ($i = 1; $i <= 200; $i++) {

            // insert data ke table pegawai menggunakan Faker
            \DB::table('dealins')->insert([
                'judul' => $faker->sentence(5, true),
                'kategori' => $faker->word,
                'kondisi' => 'baru',
                'harga' => $faker->numberBetween(1000000, 20000000),
                'file_path' => $faker->randomDigit().'.jpg',
                'desc' => $faker->paragraph,
                'kelurahan' => $faker->word,
                'kecamatan' => $faker->city,
                'kota' => $faker->city,
                'provinsi' => $faker->country,
                'user_id' =>$faker->numberBetween(1,50),
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => Carbon::now()->format('Y-m-d H:i:s')
            ]);

        }
    }
}
